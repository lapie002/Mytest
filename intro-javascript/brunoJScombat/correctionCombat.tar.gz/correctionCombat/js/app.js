var buttonCombat = document.getElementById('combat');
buttonCombat.disabled = false;

// declaration de cookie
//document.cookie = "vie=20";
// declaration en utilisant une fonction setCookie trouve sur internet
setCookie("vie", "21",4);
var valueCookie = Number(getCookie('vie'));

console.log(valueCookie);
var divVie = document.getElementById('vie');
divVie.innerHTML = valueCookie + " vies";

function getRandomArbitrary(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

buttonCombat.addEventListener('click', function(){
var nombreAleatoire = getRandomArbitrary(0, 4);
console.log(nombreAleatoire);
//var nombreAleatoire = Math.floor((Math.random() * 2 ) + 0)

//var nombreAleatoire = getRandomArbitrary(0,2);

if(nombreAleatoire === 1){
  var divResultat = document.getElementById('resultat');
  divResultat.innerHTML = "Vous avez gagné";
  console.log(buttonCombat);
  buttonCombat.disabled = true;
  setInterval(function(){
    window.location.assign("gagne.html");
  }, 4000);
  // autre façon equivalente sur 1 ligne au 2 lignes au dessus
  //document.getElementById('resultat').innerHTML = "Vous avez gagné";
}
else {
  var divResultat = document.getElementById('resultat');
  divResultat.innerHTML = "Vous avez perdu";
  --valueCookie;
  console.log(valueCookie);
  setCookie("vie", valueCookie, 4);
  var divVie = document.getElementById('vie');
  divVie.innerHTML = valueCookie + " vies";
  // autre façon equivalente sur 1 ligne au 2 lignes au dessus
  //document.getElementById('resultat').innerHTML = "Vous avez gagné";
}

});
